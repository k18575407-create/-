# CodePilot (Android, Kotlin + Compose)
Build: open this folder in Android Studio (Koala+, JDK 17) → let Gradle sync (generates the wrapper) →
Build > Generate Signed App Bundle / APK > APK > release (create a keystore when asked) → app/release/app-release.apk.
Run: Settings tab → paste API key → Chat. The AI edits files in the active project via tools.

## Implemented
Encrypted key storage, OkHttp provider (pluggable AiProvider), agent tool loop (list/read/write/edit/search/mkdir/rename/delete-with-confirm/zip),
path-traversal-safe ProjectManager, file list + plain editor, HTML/CSS/JS WebView preview (served via WebViewAssetLoader, file access off), offline banner.
## Not yet implemented (honest list)
Syntax highlighting/line numbers/undo/bracket matching in editor, Markdown rendering, conversation list/persistence, web search, SAF import/export,
code execution (nothing runs; all runs would be NOT_SUPPORTED), streaming responses, regenerate, analyze_code/preview tools for the AI.
This code has not been compiled yet — expect to fix small compile errors on first sync.
