package com.codepilot.app
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** API key + settings, encrypted with a key held in Android Keystore. Never hard-coded. */
object SecureStore {
    fun prefs(c: Context) = EncryptedSharedPreferences.create(
        c, "secure_settings",
        MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
}
